<?php
$mysqli = new mysqli('localhost', 'root', 'root', '32');

$mysqli->query(
  "CREATE TABLE IF NOT EXISTS peoplecounter (
  `record` INT(20) NOT NULL AUTO_INCREMENT,
  `datetime` VARCHAR(30),
  `people` INT(2),
  PRIMARY KEY(`record`));"
);

if($_GET['people']){
  if($_GET['key']==712){
    $people=$_GET['people'];
    $active=1;
    $mysqli->query(
      "INSERT INTO peoplecounter VALUES (
      NULL,
      '".date('Y-m-d H:i:s')."',
      '".$people."'
    );"
    );
    echo "Дані записано";
  }
  else{echo "Ключ не вірний";}
}
?>
