<!DOCTYPE HTML>
<html>
	<head>
		<meta http-equiv="Content-Type" content="text/html; charset=utf-8">
		<meta name="viewport" content="width=device-width, initial-scale=1">
		<title>Esp8266 Моніторинг електромережі</title>
		<style type="text/css">
		</style>
	</head>
	<body>
<script src="jquery-3.2.1.min.js"></script>
<script src="code/highstock.js"></script>
<script src="code/themes/dark-unica.js"></script>
<script src="code/modules/exporting.js"></script>

<div id="container2" style="height: 600px; min-width: 310px"></div>
<script>
	Highcharts.setOptions({
				lang: {
					loading: 'Завантаження...',
					months: ['Січень', 'Лютий', 'Березенб', 'Квітень', 'Травень', 'Червень', 'Липень', 'Серпень', 'Вересень', 'Жовтень', 'Листопад', 'Грудень'],
					weekdays: ['Неділя', 'Понеділок', 'Вівторок', 'Середа', 'Четвер', 'Пятниця', 'Субота'],
					shortMonths: ['Січ', 'Лют', 'Берез', 'Квіт', 'Трав', 'Черв', 'Лип', 'Серп', 'Весес', 'Жовт', 'Лист', 'Груд'],
					exportButtonTitle: "Експорт",
					printButtonTitle: "Друк",
					rangeSelectorFrom: "З",
					rangeSelectorTo: "До",
					rangeSelectorZoom: "Період",
					downloadPNG: 'Завантажити PNG',
					downloadJPEG: 'Завантажити JPEG',
					downloadPDF: 'Завантажити PDF',
					downloadSVG: 'Завантажити SVG',
					printChart: 'Друкувати графік'
				}
		});
</script>

		<script type="text/javascript">
			$.getJSON('jsonp.php', function (data) {

				// split the data set into voltage and current
				var //voltage = [],
					current = [],
					//active = [],
					dataLength = data.length,

				i = 0;
				for (i; i < dataLength; i += 1) {
					//voltage.push([
						//data[i][0] * 1000, // the date
						//data[i][1], // voltage
					//]);

					current.push([
						data[i][0] * 1000, // the date
						data[i][2] // the current
					]);

					//active.push([
						//data[i][0] * 1000, // the date
						//data[i][3] // the active power
					//]);
				}


				// create the chart
				Highcharts.stockChart('container2', {

					rangeSelector: {
						selected: 8,
						buttons: [{
							type: 'minute',
							count: 10,
							text: '10хв'
						}, {
							type: 'hour',
							count: 1,
							text: '1 год'
						}, {
							type: 'hour',
							count: 6,
							text: '6 год'
						}, {
							type: 'day',
							count: 1,
							text: '1 дн'
						}, {
							type: 'week',
							count: 1,
							text: '1 нд'
						}, {
							type: 'month',
							count: 1,
							text: '1 міс'
						}, {
							type: 'year',
							count: 1,
							text: '1 рік'
						}, {
							type: 'all',
							text: 'Все'
						}]
					},

					title: {
						text: 'Графік відвідувачів:'
					},

					yAxis: [{
						labels: {
							align: 'right',
							x: -3
						},
						//title: {
							//text: 'Напряжение'
						//},
						//height: '50%',
						//lineWidth: 1,
						//resize: {
							//enabled: true
						//}
					},
					{
						labels: {
							align: 'right',
							x: -3
						},
						title: {
							text: 'Кількість людей'
						},
						top: '0%',
						height: '100%',
						offset: 0,
						lineWidth: 1
					}, {
						//labels: {
							//align: 'right',
							//x: -3
						//},
						//title: {
						//	text: 'Потужність'
						//},
						//top: '52%',
						//height: '48%',
						//offset: 0,
						//lineWidth: 1
					}],

					tooltip: {
						split: true
					},

					series: [{
						//type: 'spline',
						//name: 'Вольт',
						//data: voltage,
						//yAxis: 0
					}, {
						type: 'spline',
						name: 'Людей',
						data: current,
						yAxis: 1
					}, {
						//type: 'spline',
						//name: 'Ватт',
						//data: active,
						//yAxis: 2
					}]
				});
			});
		</script>
	</body>
</html>
